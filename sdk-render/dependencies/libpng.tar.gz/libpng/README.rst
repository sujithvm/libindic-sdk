libpng for Android 
==================
This is a repackaging of libpng 1.4.1 for Android by Julien Rebetez.

Most changes went in config.h and writing the Makefiles.

The original libpng website is : http://www.libpng.org/pub/png/libpng.html

Assuming 'ndk-build' is in your path, you can use the build.sh script to create a static library.

